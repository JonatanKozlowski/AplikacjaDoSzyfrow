import tkinter as tk
from tkinter import messagebox, filedialog, PhotoImage
from Crypto.Cipher import AES
import base64

BG_COLOR = "#121212"
FG_COLOR = "#E0E0E0"
BUTTON_COLOR = "#2A2A2A"
BUTTON_TEXT_COLOR = "#E0E0E0"

file_content = None
file_path = None

def center_window(window, width, height):
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
    x = (screen_width // 2) - (width // 2)
    y = (screen_height // 2) - (height // 2)
    window.geometry(f"{width}x{height}+{x}+{y}")

def go_back(window):
    window.destroy()
    main_window.destroy()
    main_window()

def create_button(parent, text, command):
    return tk.Button(parent, text=text, command=command, bg=BUTTON_COLOR, fg=BUTTON_TEXT_COLOR,
                     font=("Helvetica", 12), relief="flat", borderwidth=0, activebackground=BUTTON_COLOR,
                     highlightthickness=0, padx=20, pady=5)

def open_cipher_window(mode, is_file=False):
    global file_content, file_path
    cipher_root = tk.Toplevel()
    title = "AES Szyfrowanie" if mode == "encrypt" else "AES Deszyfrowanie"
    title += " pliku" if is_file else " tekstu"
    cipher_root.title(title)
    cipher_root.configure(bg=BG_COLOR)
    center_window(cipher_root, 500, 450)

    tk.Label(cipher_root, text="Plik do zaszyfrowania:" if is_file else "Tekst do szyfrowania:", 
             bg=BG_COLOR, fg=FG_COLOR, font=("Helvetica", 12)).pack(pady=5)

    if not is_file:
        entry_text = tk.Text(cipher_root, height=5, width=50, bg=BUTTON_COLOR, fg=FG_COLOR, insertbackground=FG_COLOR,
                             relief="flat", font=("Helvetica", 12), )
        entry_text.pack(pady=5, padx=10)

    tk.Label(cipher_root, text="Klucz (16, 24, 32 znaki):", bg=BG_COLOR, fg=FG_COLOR, font=("Helvetica", 12)).pack(pady=5)
    entry_key = tk.Entry(cipher_root, width=50, show="*", bg=BUTTON_COLOR, fg=FG_COLOR, insertbackground=FG_COLOR,
                         relief="flat", font=("Helvetica", 12), )
    entry_key.pack(pady=5, padx=10)

    if not is_file:
        tk.Label(cipher_root, text="Wynik:", bg=BG_COLOR, fg=FG_COLOR, font=("Helvetica", 12)).pack(pady=5)
        output_text = tk.Text(cipher_root, height=5, width=50, bg=BUTTON_COLOR, fg=FG_COLOR, insertbackground=FG_COLOR,
                              relief="flat", font=("Helvetica", 12),)
        output_text.pack(pady=5, padx=10)

    def encrypt():
        key = entry_key.get()
        if len(key) not in [16, 24, 32]:
            messagebox.showerror("Błąd", "Klucz musi mieć 16, 24 lub 32 znaki!")
            return
        if is_file:
            global file_content
            if not file_content:
                messagebox.showerror("Błąd", "Nie wybrano pliku!")
                return
            cipher = AES.new(key.encode(), AES.MODE_GCM)
            ciphertext, tag = cipher.encrypt_and_digest(file_content)
            encrypted_data = cipher.nonce + ciphertext + tag
            save_file(encrypted_data)
        else:
            text = entry_text.get("1.0", tk.END).strip()
            cipher = AES.new(key.encode(), AES.MODE_GCM)
            ciphertext, tag = cipher.encrypt_and_digest(text.encode())
            encrypted_data = base64.b64encode(cipher.nonce + ciphertext + tag).decode()
            output_text.delete("1.0", tk.END)
            output_text.insert("1.0", encrypted_data)

    def decrypt():
        key = entry_key.get()
        if len(key) not in [16, 24, 32]:
            messagebox.showerror("Błąd", "Klucz musi mieć 16, 24 lub 32 znaki!")
            return
        if is_file:
            global file_content
            if not file_content:
                messagebox.showerror("Błąd", "Nie wybrano pliku!")
                return
            try:
                nonce, ciphertext, tag = file_content[:16], file_content[16:-16], file_content[-16:]
                cipher = AES.new(key.encode(), AES.MODE_GCM, nonce=nonce)
                decrypted_data = cipher.decrypt_and_verify(ciphertext, tag)
                save_file(decrypted_data)
            except Exception:
                messagebox.showerror("Błąd", "Niepoprawny klucz lub zaszyfrowany plik!")
        else:
            encrypted_text = entry_text.get("1.0", tk.END).strip()
            try:
                data = base64.b64decode(encrypted_text)
                nonce, ciphertext, tag = data[:16], data[16:-16], data[-16:]
                cipher = AES.new(key.encode(), AES.MODE_GCM, nonce=nonce)
                decrypted_text = cipher.decrypt_and_verify(ciphertext, tag).decode()
                output_text.delete("1.0", tk.END)
                output_text.insert("1.0", decrypted_text)
            except Exception:
                messagebox.showerror("Błąd", "Niepoprawny klucz lub zaszyfrowany tekst!")

    def load_file():
        global file_content, file_path
        file_path = filedialog.askopenfilename(filetypes=[("Pliki tekstowe", "*.txt")])
        if file_path:
            with open(file_path, "rb") as file:
                file_content = file.read()
            messagebox.showinfo("Sukces", "Plik został zapisany w pamięci. Teraz wprowadź klucz.")

    def save_file(data):
        save_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Pliki tekstowe", "*.txt")])
        if save_path:
            with open(save_path, "wb") as file:
                file.write(data)
            messagebox.showinfo("Sukces", "Plik został zapisany!")

    if is_file:
        create_button(cipher_root, "📂 Wybierz plik", load_file).pack(pady=10)
    if mode == "encrypt":
        create_button(cipher_root, "🔐 Szyfruj", encrypt).pack(pady=10)
    else:
        create_button(cipher_root, "🔓 Odszyfruj", decrypt).pack(pady=10)

    create_button(cipher_root, "🔙 Powrót", lambda: go_back(cipher_root)).pack(pady=10)

def main_window():
    global root
    root = tk.Tk()
    root.title("AES Encryptor")
    root.configure(bg=BG_COLOR)
    center_window(root, 400, 300)
    
    try:
        icon = PhotoImage(file="icon.png")
        root.tk.call("wm", "iconphoto", root._w, icon)
    except:
        pass

    tk.Label(root, text="AES Encryptor", font=("Helvetica", 18, "bold"), bg=BG_COLOR, fg=FG_COLOR).pack(pady=20)

    create_button(root, "🔐 Szyfruj tekst", lambda: open_cipher_window("encrypt", False)).pack(pady=10)
    create_button(root, "🔓 Odszyfruj tekst", lambda: open_cipher_window("decrypt", False)).pack(pady=10)
    create_button(root, "📂 Szyfruj plik", lambda: open_cipher_window("encrypt", True)).pack(pady=10)
    create_button(root, "📂 Odszyfruj plik", lambda: open_cipher_window("decrypt", True)).pack(pady=10)

    root.mainloop()

main_window()
